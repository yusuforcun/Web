﻿namespace ogrenci_mvc.Models
{
    public class Ogrenci
    {
        public string ogrenciadi { get; set; }
        public string ogrencisoyadi { get; set; }
        public string sinif {  get; set; }  
    }
}
